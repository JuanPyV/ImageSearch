const express = require("express");
const app = express();
const { searchImage } = require("./search");

app.listen(3000, () => {
  console.log("Application started and Listening on port 3000");
});

app.use(express.static(__dirname + "/src"));
app.use('/images', express.static('../images'));
app.use(express.urlencoded({ extended: true }));

app.get("/", (req, res) => {
  res.sendFile(__dirname + "/src/index.html");
});

app.post('/images', (req, res) => {
  searchOpt = req.body.imageOpt;
  let grepExpr = "";
  if (searchOpt){ 
    if(searchOpt == "id"){
      grepExpr = `grep -nl '${searchOpt}:${req.body.searchTerm}' ../images/*`
      console.log("main.js ID EXPRESSION: "  + grepExpr);

    }else if(searchOpt == "tag"){
      let searchTags = req.body.searchTerm.split(" ").filter(Boolean);
      let regex = ""
      console.log("SEARCH: " + searchTags);
      for(let i = 0; i<searchTags.length; i++){
        if(searchTags[i] !== ""){
          if(i === searchTags.length-1){
            regex = regex + `${searchOpt}:.*${searchTags[i]}`;
          }else{
            regex = regex + `${searchOpt}:.*${searchTags[i]}|`;
          }
        }
      }
      grepExpr = grepExpr + `grep -E -nl '${regex}' ../images/*`;
    } 
    console.log(grepExpr);
  }  
  searchImage(grepExpr, res);
});
