const { exec } = require("child_process");

const searchImage = function(grepExpr, res){
  try {
    exec(grepExpr, (error, stdout, stderr) => {
      if (error) {
        console.error(`exec error: ${error}`);
        res.sendStatus(404).send("Server error while finding file");
        return;
      }else if (stdout){
        filesDir = stdout.split("\n");
        res.send(filesDir);
      }  
    });
  } catch (error) {
    //console.error(`exec error: ${error}`);
    console.log(`File with '${expr}' not found!`)
    res.sendStatus(404).send("Server error while finding file");
        
  }
  
} 

exports.searchImage = searchImage;
