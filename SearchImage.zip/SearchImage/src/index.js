const search = $(".searchButton");
const image_container = $(".imagesContainer");  
var modal = document.getElementById("myModal");
var spanClose = document.getElementsByClassName("close")[0];

function getImages(){
    let expr = {
        imageOpt: $('.form input:checked')[0].value,
        searchTerm: $('.form .searchTerm')[0].value
    };
    
    console.log("index.js searchTerm " + expr.searchTerm);

    if(expr.imageOpt && expr.searchTerm){
        $.ajax({
            url: '/images',
            type: 'POST',
            data: expr,
            success: function(res){          
                for(let i = 0; i<res.length; i++){
                    if(res[i] !== ""){
                        imageDir = res[i].substring(2);
                        let newImage = document.createElement("div");
                        newImage.classList.add("member");
                        newImage.innerHTML =
                        `
                        <span class="image-id" hidden>${i}</span>
                        <img id="img-${i}" src="${imageDir}" class="img-responsive img-thumbnail" alt="${res[i].substring(10)}" />
                        <div class="name">${res[i].substring(10)}</div>
                        `;
                        image_container.append(newImage);
                    }
                }
            }
        });
    }else{
        console.log("Please enter a value");
    }
}

search.on("click", (e) => {
    e.preventDefault();
    $(".imagesContainer").empty();
    getImages();
});


image_container.on('click', (e) => {
    const currentNote = e.target.closest('.member');
    const id = currentNote.querySelector('span.image-id').textContent;
    openModal(id);
});

function openModal(id){
    var img = document.getElementById(`img-${id}`);
    var modalImg = document.getElementById("modal-img");
    var captionText = document.getElementById("caption");
        img.onclick = function(){
        modal.style.display = "block";
        modalImg.src = this.src;
        captionText.innerHTML = this.alt;
    }
}


spanClose.onclick = function() { 
  modal.style.display = "none";
}
